"""
##################################################################################################
# Copyright Info :    Copyright (c) Davar Lab @ Hikvision Research Institute. All rights reserved.
# Filename       :    version.py
# Abstract       :

# Current Version:    0.5.0
# Date           :    2022-05-08
##################################################################################################
"""
__version__ = "0.5.0"
