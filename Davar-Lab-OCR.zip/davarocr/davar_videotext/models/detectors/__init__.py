"""
##################################################################################################
# Copyright Info :    Copyright (c) Davar Lab @ Hikvision Research Institute. All rights reserved.
# Filename       :    __init__.py
# Abstract       :

# Current Version:    1.0.0
# Date           :    2021-05-25
##################################################################################################
"""

from .spatial_temporal_east_det import SpatialTempoEASTDet

__all__ = ['SpatialTempoEASTDet']
