"""
##################################################################################################
# Copyright Info :    Copyright (c) Davar Lab @ Hikvision Research Institute. All rights reserved.
# Filename       :    __init__.py
# Abstract       :

# Current Version:    1.0.0
# Date           :    2021-06-05
##################################################################################################
"""

from .text_recommender import TextRecommender

__all__ = [
    'TextRecommender',
]
