class Loader:
    # def load(self, basename):        
    #     pass
    
    def read_all(self):
        pass
    
    def sample_n(self, n):
        pass

    def get_by_filename(self, filename):
        pass
    
        
        